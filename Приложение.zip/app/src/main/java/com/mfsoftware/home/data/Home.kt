package com.mfsoftware.home.data

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
data class Home (val id: String, val address: String, val localIp: String, val rooms: Array<String>): Parcelable {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (javaClass != other?.javaClass) return false

        other as Home

        if (id != other.id) return false
        if (address != other.address) return false
        if (localIp != other.localIp) return false
        if (!rooms.contentEquals(other.rooms)) return false

        return true
    }

    override fun hashCode(): Int {
        var result = id.hashCode()
        result = 31 * result + address.hashCode()
        result = 31 * result + localIp.hashCode()
        result = 31 * result + rooms.contentHashCode()
        return result
    }
}