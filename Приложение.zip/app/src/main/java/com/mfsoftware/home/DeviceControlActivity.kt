package com.mfsoftware.home

import android.content.Context
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.beust.klaxon.Klaxon
import kotlinx.android.synthetic.main.activity_device_control.*
import okhttp3.*

class DeviceControlActivity : AppCompatActivity() {

    private lateinit var client: OkHttpClient
    private lateinit var socketToken: String

    class Handshake {
        val type = "handshake"
        val sender = "user"
        val token = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiJFWVFjYmtJYWlvRkg0N0tuIiwiZmluZ2VycHJpbnQiOiJlejJYbktnekNwVDZmcDRiUm0yTG1lQzgzcUhza0Zsc0RjeU5mdmEwTUF3PSIsImlhdCI6MTU5MDc3MTQ3M30.0_eEfOSMddNtUYQukiNFh80CU1b3Dsiejt8BnEYs5hs"

        val handshakeType = "reconnect"
    }

    class UnknownMessage {
        val type: String = ""
    }

    class EventBody {

    }

    class Event(t: String) {
        val type: String = "event"
        val token = t
        val target = "device"
        val homeId = "prCijjNqahlVUGt3"
        val deviceId = "84f95c9f-0a37-410f-b85c-00fcfb31c6cd"

        val eventBody: EventBody = EventBody()
    }

    class SocketListener : WebSocketListener() {
        @Override
        override fun onOpen(webSocket: WebSocket, response: Response) {
            webSocket.send(Klaxon().toJsonString(Handshake()))
        }

        @Override
        override fun onMessage(webSocket: WebSocket, text: String) {
            val message = Klaxon().parse<UnknownMessage>(text)

            when (message?.type) {
                "error" -> {

                }
                "response" -> {

                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_device_control)

        val prefs = getSharedPreferences("user", Context.MODE_PRIVATE)
        socketToken = prefs.getString("socketToken", "")!!

        client = OkHttpClient()

        val request = Request.Builder().url("wss://home.mfsoftware.site/ws").build()
        val ws = client.newWebSocket(request, SocketListener())

        button.setOnClickListener {
            ws.send(Klaxon().toJsonString(Event("eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiJFWVFjYmtJYWlvRkg0N0tuIiwiZmluZ2VycHJpbnQiOiJlejJYbktnekNwVDZmcDRiUm0yTG1lQzgzcUhza0Zsc0RjeU5mdmEwTUF3PSIsImlhdCI6MTU5MDc3MTQ3M30.0_eEfOSMddNtUYQukiNFh80CU1b3Dsiejt8BnEYs5hs")))
        }
    }
}
