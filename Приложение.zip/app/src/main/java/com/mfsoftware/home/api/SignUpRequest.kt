package com.mfsoftware.home.api

class SignUpRequest(var username: String, var password: String, var email: String, var firstname: String, var secondname: String)