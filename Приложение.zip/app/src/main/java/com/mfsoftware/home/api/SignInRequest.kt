package com.mfsoftware.home.api

class SignInRequest(var userName: String, var password: String)