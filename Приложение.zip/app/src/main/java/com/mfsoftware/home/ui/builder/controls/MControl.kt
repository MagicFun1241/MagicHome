package com.mfsoftware.home.ui.builder.controls

import com.beust.klaxon.Klaxon

enum class ControlType(val value: String) {
    Label("label"),
    Button("button")
}

open class MControl(val type: ControlType) {
    companion object {
        @JvmStatic
        inline fun <reified T> parse(json: String): T? {
            return Klaxon().parse<T>(json)
        }
    }
}