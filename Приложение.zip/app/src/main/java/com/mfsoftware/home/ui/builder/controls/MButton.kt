package com.mfsoftware.home.ui.builder.controls

class MButton(val label: String, type: ControlType) : MControl(type)