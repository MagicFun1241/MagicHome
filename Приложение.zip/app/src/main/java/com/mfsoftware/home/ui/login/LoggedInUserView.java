package com.mfsoftware.home.ui.login;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Class exposing authenticated user details
 */
public class LoggedInUserView implements Parcelable {
    private String userName;
    private String firstName;

    private String apiToken;
    private String socketToken;

    public LoggedInUserView(String userName, String firstName, String apiToken,String socketToken) {
        this.userName = userName;
        this.firstName = firstName;

        this.apiToken = apiToken;
        this.socketToken = socketToken;
    }

    public LoggedInUserView(String userName, String firstName) {
        this.userName = userName;
        this.firstName = firstName;
    }

    private LoggedInUserView(Parcel in) {
        userName = in.readString();
        firstName = in.readString();
        apiToken = in.readString();
        socketToken = in.readString();
    }

    public static final Creator<LoggedInUserView> CREATOR = new Creator<LoggedInUserView>() {
        @Override
        public LoggedInUserView createFromParcel(Parcel in) {
            return new LoggedInUserView(in);
        }

        @Override
        public LoggedInUserView[] newArray(int size) {
            return new LoggedInUserView[size];
        }
    };

    public String getUserName() {
        return userName;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getApiToken() {
        return apiToken;
    }

    public String getSocketToken() {
        return socketToken;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(userName);
        dest.writeString(firstName);
        dest.writeString(apiToken);
        dest.writeString(socketToken);
    }
}
