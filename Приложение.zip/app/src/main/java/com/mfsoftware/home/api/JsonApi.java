package com.mfsoftware.home.api;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.Header;
import retrofit2.http.POST;
import retrofit2.http.Path;
import retrofit2.http.Query;

public interface JsonApi {
    @POST("user/signin")
    Call<SignInResponse> signIn(@Body SignInRequest body, @Header("Fingerprint") String fingerPrint);

    @POST("user/register")
    Call<SignUpResponse> registerUser(@Body SignUpRequest body, @Header("Fingerprint") String fingerPrint);

    @GET("homes/{home}/rooms/{room}/devices")
    Call<GetDevicesResponse> getDevices(@Path("home") String homeId, @Header("Fingerprint") String fingerPrint, @Header("Authorization") String token);

    @GET("homes/{home}/device/{id}")
    Call<SignInResponse> getDevice(@Path("id") String id, @Header("Fingerprint") String fingerPrint, @Header("Authorization") String token);

    @GET("homes/{home}/rooms")
    Call<GetRoomsResponse> getRooms(@Path("home") String homeId, @Header("Fingerprint") String fingerPrint, @Header("Authorization") String token, @Query("extended") boolean extended);

    @GET("homes")
    Call<GetHomesResponse> getHomes(@Header("Fingerprint") String fingerPrint, @Header("Authorization") String token);
}
