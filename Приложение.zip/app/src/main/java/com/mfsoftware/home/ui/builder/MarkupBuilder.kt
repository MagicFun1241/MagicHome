package com.mfsoftware.home.ui.builder

import android.content.Context
import android.widget.LinearLayout
import android.widget.TextView
import com.beust.klaxon.Klaxon
import com.mfsoftware.home.ui.builder.controls.ControlType
import com.mfsoftware.home.ui.builder.controls.MButton
import com.mfsoftware.home.ui.builder.controls.MControl

class BaseMarkup(val controls: Array<MControl>)

class MarkupBuilder(context: Context) {
    private var base: BaseMarkup? = null
    private var activityContext: Context? = context
    private var linearLayout: LinearLayout? = null

    init {
        linearLayout = LinearLayout(context)
    }

    fun run() {
        if (base == null) throw Error("Markup is not parsed")
        base!!.controls.forEach {
            when (it.type) {
                ControlType.Label -> {

                }
                ControlType.Button -> {
                    val c = MControl.parse<MButton>(it.toString())

                    val v = TextView(activityContext)
                    if (c != null) {
                        v.text = c.label
                    }

                    linearLayout?.addView(v)
                }
            }
        }
    }

    fun parse(json: String): MarkupBuilder {
        this.base = MarkupBuilder.parse(json)

        return this
    }

    companion object {
        @JvmStatic
        fun parse(text: String): BaseMarkup? {
            return Klaxon().parse<BaseMarkup>(text);
        }
    }
}