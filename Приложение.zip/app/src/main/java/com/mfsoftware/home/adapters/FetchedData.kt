package com.mfsoftware.home.adapters

import android.os.Parcelable
import com.mfsoftware.home.data.Home
import com.mfsoftware.home.data.Room
import kotlinx.android.parcel.Parcelize

@Parcelize
data class FetchedData(val rooms: List<Room>, val homes: List<Home>) : Parcelable {
    companion object {
        @JvmStatic
        fun parse(rooms: List<Room>, homes: List<Home>): FetchedData {
            return FetchedData(rooms, homes)
        }

        @JvmStatic
        fun parseRealm(rooms: List<com.mfsoftware.home.models.Room>, homes: List<com.mfsoftware.home.models.Home>): FetchedData {
            val homesList = ArrayList<Home>()
            homes.forEach { homesList.add(Home(it.id, it.address, it.localIp, arrayOf("hello"))) }

            val roomsList = ArrayList<Room>()

            return FetchedData(roomsList, homesList)
        }
    }
}