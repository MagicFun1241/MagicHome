package com.mfsoftware.home.api

import com.google.gson.annotations.SerializedName

class SignInResponse {
    @SerializedName("apiToken")
    lateinit var apiToken: String

    @SerializedName("socketToken")
    lateinit var socketToken: String

    @SerializedName("userName")
    lateinit var userName: String

    @SerializedName("firstName")
    lateinit var firstName: String

    @SerializedName("photo")
    lateinit var photo: String
}